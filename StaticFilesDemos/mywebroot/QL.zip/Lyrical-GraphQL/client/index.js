import React from 'react';
import ReactDOM from 'react-dom';

const Root = () => {
  return <div>Lyrical</div>
};

ReactDOM.render(
  <Root />,
  document.querySelector('#root')
);
