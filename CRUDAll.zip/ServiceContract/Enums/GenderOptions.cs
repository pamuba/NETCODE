﻿using System;

namespace ServiceContract.Enums
{
    public enum GenderOptions
    {
        Male, Female, Other
    }
}