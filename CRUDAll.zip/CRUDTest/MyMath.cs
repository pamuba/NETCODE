﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDTest
{
    internal class MyMath
    {
        public int Add(int a, int b) {
            int c = a + b;
            return c;
        }
    }
}
